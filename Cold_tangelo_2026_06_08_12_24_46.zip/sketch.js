// Captura de Elementos do DOM
const canvas = document.getElementById('simuladorCanvas');
const ctx = canvas.getContext('2d');
const sliderMaquinas = document.getElementById('slider-maquinas');
const sliderArvores = document.getElementById('slider-arvores');
const valMaquinas = document.getElementById('val-maquinas');
const valArvores = document.getElementById('val-arvores');
const kpiProducao = document.getElementById('kpi-producao');
const kpiSustentabilidade = document.getElementById('kpi-sustentabilidade');
const alertaImpacto = document.getElementById('alerta-impacto');

// Arrays de gerenciamento dos elementos móveis e estáticos
let colheitadeiras = [];
let caminhoes = [];
let arvores = [];

// Instanciação e carregamento seguro dos Sprites (Imagens Externas)
const imgFundo = new Image(); imgFundo.src = 'cenario_fundo.png';
const imgColheitadeira = new Image(); imgColheitadeira.src = 'colheitadeira.png';
const imgCaminhao = new Image(); imgCaminhao.src = 'caminhao.png';
const imgArvore = new Image(); imgArvore.src = 'arvore.png';

// Ouvintes de eventos para atualização dinâmica da interface
sliderMaquinas.addEventListener('input', (e) => {
    valMaquinas.textContent = e.target.value;
    atualizarElementos();
});

sliderArvores.addEventListener('input', (e) => {
    valArvores.textContent = e.target.value;
    atualizarElementos();
});

// Inicialização de posições aleatórias para as árvores
function inicializarArvores() {
    arvores = [];
    let qtd = 5 + (parseInt(sliderArvores.value) * 5);
    for (let i = 0; i < qtd; i++) {
        arvores.push({
            x: Math.random() * (750 - 450) + 450, // Lado direito (Preservação)
            y: Math.random() * (400 - 150) + 150
        });
    }
}

// Sincroniza a quantidade de veículos e árvores com o valor dos Sliders
function atualizarElementos() {
    let qtdMaquinas = parseInt(sliderMaquinas.value);
    
    // Ajusta colheitadeiras
    while (colheitadeiras.length < qtdMaquinas) {
        colheitadeiras.push({ x: Math.random() * 200, y: Math.random() * (280 - 150) + 150, vel: Math.random() * 0.8 + 0.5 });
    }
    while (colheitadeiras.length > qtdMaquinas) colheitadeiras.pop();

    // Ajusta caminhões proporcionalmente
    let qtdCaminhoes = Math.floor(qtdMaquinas * 0.8);
    while (caminhoes.length < qtdCaminhoes) {
        caminhoes.push({ x: Math.random() * 200, y: Math.random() * (420 - 320) + 320, vel: Math.random() * 1.2 + 0.8 });
    }
    while (caminhoes.length > qtdCaminhoes) caminhoes.pop();

    // Ajusta árvores
    let qtdArvoresAlvo = 5 + (parseInt(sliderArvores.value) * 5);
    while (arvores.length < qtdArvoresAlvo) {
        arvores.push({ x: Math.random() * (750 - 430) + 430, y: Math.random() * (420 - 150) + 150 });
    }
    while (arvores.length > qtdArvoresAlvo) arvores.pop();
}

// Calcula fórmulas de impacto e atualiza os cartões de KPI textuais
function calcularRegrasNegocio() {
    let maq = parseInt(sliderMaquinas.value);
    let arv = parseInt(sliderArvores.value);

    let prod = 20 + (maq * 16);
    let sust = 50 + (arv * 10) - (maq * 14);
    sust = Math.max(0, Math.min(100, sust)); // Constrain entre 0 e 100

    kpiProducao.textContent = `${prod}%`;
    kpiSustentabilidade.textContent = `${sust}%`;

    if (sust < 30) {
        alertaImpacto.classList.remove('oculto');
    } else {
        alertaImpacto.classList.add('oculto');
    }
}

// Loop principal de renderização do Canvas (Substitui o draw do p5.js)
function render() {
    // Limpa a tela
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // 1. Desenha o Fundo (com tratamento caso a imagem ainda não tenha carregado)
    if (imgFundo.complete && imgFundo.naturalWidth !== 0) {
        ctx.drawImage(imgFundo, 0, 0, canvas.width, canvas.height);
    } else {
        // Fallback visual elegante caso as imagens não existam na pasta ainda
        ctx.fillStyle = "#e2e8f0";
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = "#854d0e"; // Lado Lavoura
        ctx.fillRect(0, 150, 400, 350);
        ctx.fillStyle = "#15803d"; // Lado Preservação
        ctx.fillRect(400, 150, 400, 350);
    }

    // Linha divisória conceitual entre lavoura e reserva
    ctx.strokeStyle = "rgba(0, 0, 0, 0.15)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(400, 0);
    ctx.lineTo(400, canvas.height);
    ctx.stroke();

    // 2. Movimenta e Desenha as Colheitadeiras
    colheitadeiras.forEach(c => {
        c.x += c.vel;
        if (c.x > 340) c.x = -60; // Retorna em loop contínuo
        if (imgColheitadeira.complete && imgColheitadeira.naturalWidth !== 0) {
            ctx.drawImage(imgColheitadeira, c.x, c.y, 65, 45);
        } else {
            ctx.fillStyle = "#b91c1c"; // Retângulo vermelho substituto
            ctx.fillRect(c.x, c.y, 60, 40);
        }
    });

    // 3. Movimenta e Desenha os Caminhões
    caminhoes.forEach(cam => {
        cam.x += cam.vel;
        if (cam.x > 340) cam.x = -70;
        if (imgCaminhao.complete && imgCaminhao.naturalWidth !== 0) {
            ctx.drawImage(imgCaminhao, cam.x, cam.y, 75, 40);
        } else {
            ctx.fillStyle = "#1e3a8a"; // Retângulo azul substituto
            ctx.fillRect(cam.x, cam.y, 70, 35);
        }
    });

    // 4. Desenha as Árvores Estáticas
    arvores.forEach(a => {
        if (imgArvore.complete && imgArvore.naturalWidth !== 0) {
            ctx.drawImage(imgArvore, a.x, a.y, 35, 55);
        } else {
            ctx.fillStyle = "#166534"; // Círculo verde substituto
            ctx.beginPath();
            ctx.arc(a.x + 15, a.y + 20, 15, 0, Math.PI * 2);
            ctx.fill();
        }
    });

    // Executa as regras de negócio de maneira contínua
    calcularRegrasNegocio();

    // Solicita o próximo frame para animação suave de 60fps nativa
    requestAnimationFrame(render);
}

// Inicialização do Sistema ao carregar a página
inicializarArvores();
atualizarElementos();
render();
